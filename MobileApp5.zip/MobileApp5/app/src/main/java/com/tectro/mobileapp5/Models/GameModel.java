package com.tectro.mobileapp5.Models;

import android.os.AsyncTask;
import android.os.ResultReceiver;
import android.os.SystemClock;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

public class GameModel {
    //region Singleton
    private static GameModel current;

    public static GameModel CreateInstance(int itemCount) {
        if (current == null) current = new GameModel(itemCount);
        return current;
    }

    public static GameModel GetInstance() {
        return current;
    }

    public static GameModel RebuildInstance(int itemCount) {
        current = new GameModel(itemCount);
        return current;
    }
    //endregion

    //region Constructor
    private GameModel(int itemCount) {
        Score = 0;
        rand = new Random();
        CellsContainer = new ArrayList<>();
        for (int i = 0; i < itemCount; i++)
            CellsContainer.add(new Cell(false, CellsContainer, null));
    }
    //endregion

    //region Accessors
    public void setEndGameProvider(Consumer<Integer> endGameProvider) {
        EndGameProvider = endGameProvider;
    }

    public void SetUpdateStateProvider(BiConsumer<Integer, Boolean> UpdateStateProvider) {
        for (Cell cell : CellsContainer)
            cell.setUpdateStateProvider(UpdateStateProvider);
    }
    //endregion

    private Random rand;

    private ArrayList<Cell> CellsContainer;

    private Integer Score;

    private Consumer<Integer> EndGameProvider;

    private MyAsync GameThread;

    public void StartGame(float Seconds, float minOnTimeSec, float maxOnTimeSec, float maxDelaySec) {
        if (GameThread != null && !GameThread.isCancelled()) {
            GameThread.cancel(true);
            Score = 0;
            for (Cell cell : CellsContainer)
                cell.setPressed(false);
        }
        new MyAsync().execute(Seconds, minOnTimeSec, maxOnTimeSec, maxDelaySec);
    }

    class MyAsync extends AsyncTask<Float, Float, Void> {


        @Override
        protected Void doInBackground(Float... seconds) {
            long sec = (long) seconds[0].floatValue();
            float minOnTime = seconds[1];
            float maxOnTime = seconds[2];
            float maxDelay = seconds[3];
            while (sec > 0) {
                ///////////////////////////////////////////
                float delay = rand.nextFloat() * maxDelay;
                SystemClock.sleep((long) (delay * 1000));
                sec -= delay;
                ///////////////////////////////////////////

                Cell chosen = CellsContainer.get(rand.nextInt(CellsContainer.size()));
                chosen.setPressed(true);
                float onTime = rand.nextFloat() * (maxOnTime - minOnTime) + minOnTime;
                SystemClock.sleep((long) (onTime * 1000));
                if (chosen.getPressed())
                    Score--;
                else
                    Score++;
                chosen.setPressed(false);
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void runnable) {
            super.onPostExecute(runnable);
            CallEndGameProvider(Score);
        }
    }

    //region Helpers
    private boolean CallEndGameProvider(Integer FinalScore) {
        if (EndGameProvider != null) {
            EndGameProvider.accept(FinalScore);
            return true;
        }
        return false;
    }
    //endregion
}
