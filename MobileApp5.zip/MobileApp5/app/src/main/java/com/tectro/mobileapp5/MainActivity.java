package com.tectro.mobileapp5;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.tectro.mobileapp5.Models.GameModel;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        GModel = GameModel.CreateInstance(9);
        GModel.setEndGameProvider(this::GameEnded);
    }

    private GameModel GModel;

    public void StartGame(View view) {
        GModel.StartGame(10f,0.5f,2f,3);
    }

    @SuppressLint("SetTextI18n")
    private void GameEnded (Integer score)
    {
        ((TextView)findViewById(R.id.GameInfo)).setText("ваш итоговый счет "+score);
    }
}